# Rocket League Replays Site

This project is a web application designed to display Rocket League replays using the Ballchasing API. It is built with modern JavaScript and utilizes Vite as the build tool. The application is deployed on GitHub Pages.

## Project Structure

```
rocket-league-replays-site
├── src
│   ├── app.js               # Main entry point of the application
│   ├── api
│   │   ├── ballchasing.js   # Functions to interact with the Ballchasing API
│   │   └── github-pages.js   # Functions for GitHub Pages interactions
│   ├── sections
│   │   └── replays.js       # Logic for displaying replays
│   ├── state
│   │   └── index.js         # Application state management
│   ├── utils
│   │   └── fetch.js         # Utility functions for HTTP requests
│   └── types
│       └── index.d.ts       # Type definitions for TypeScript
├── public
│   ├── index.html           # Main HTML file for the application
│   └── 404.html             # Custom 404 error page
├── .github
│   └── workflows
│       └── pages.yml        # GitHub Actions workflow for deployment
├── package.json              # npm configuration file
├── vite.config.js           # Vite configuration file
└── README.md                # Project documentation
```

## Setup Instructions

1. **Clone the repository:**
   ```
   git clone https://github.com/yourusername/rocket-league-replays-site.git
   cd rocket-league-replays-site
   ```

2. **Install dependencies:**
   ```
   npm install
   ```

3. **Run the development server:**
   ```
   npm run dev
   ```

4. **Build the project for production:**
   ```
   npm run build
   ```

5. **Deploy to GitHub Pages:**
   The project is configured to deploy automatically to GitHub Pages using GitHub Actions. Ensure that your repository settings are configured to serve from the `gh-pages` branch.

## Usage

- Navigate to the home page to view the latest Rocket League replays.
- Use the search functionality to find specific replays.
- Click on a replay to view detailed information and statistics.

## Contributing

Contributions are welcome! Please open an issue or submit a pull request for any enhancements or bug fixes.

## License

This project is licensed under the MIT License. See the LICENSE file for details.