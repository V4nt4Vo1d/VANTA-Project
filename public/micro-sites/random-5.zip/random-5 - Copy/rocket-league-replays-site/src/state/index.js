const state = {
    replays: [],
    selectedReplay: null,
};

const setReplays = (replays) => {
    state.replays = replays;
};

const setSelectedReplay = (replay) => {
    state.selectedReplay = replay;
};

const getReplays = () => {
    return state.replays;
};

const getSelectedReplay = () => {
    return state.selectedReplay;
};

export { setReplays, setSelectedReplay, getReplays, getSelectedReplay };