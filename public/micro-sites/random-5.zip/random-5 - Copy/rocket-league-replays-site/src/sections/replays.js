import { fetchReplays } from '../api/ballchasing';
import { updateState } from '../state/index';

export const renderReplays = (replays) => {
    const replayList = document.getElementById('replay-list');
    replayList.innerHTML = '';

    replays.forEach(replay => {
        const replayItem = document.createElement('li');
        replayItem.textContent = `${replay.title} - ${replay.date}`;
        replayItem.onclick = () => updateReplayDetails(replay.id);
        replayList.appendChild(replayItem);
    });
};

export const updateReplayList = async () => {
    const replays = await fetchReplays();
    updateState({ replays });
    renderReplays(replays);
};

const updateReplayDetails = (replayId) => {
    // Logic to update the replay details view
};