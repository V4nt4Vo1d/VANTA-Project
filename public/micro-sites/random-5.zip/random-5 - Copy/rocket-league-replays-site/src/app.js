const express = require('express');
const { fetchReplays } = require('./api/ballchasing');
const { renderReplays } = require('./sections/replays');
const { state } = require('./state');

const app = express();
const PORT = process.env.PORT || 3000;

// Middleware to serve static files
app.use(express.static('public'));

// Route to fetch and display replays
app.get('/replays', async (req, res) => {
    try {
        const replays = await fetchReplays();
        state.replays = replays;
        res.send(renderReplays(replays));
    } catch (error) {
        res.status(500).send('Error fetching replays');
    }
});

// Fallback route for 404
app.use((req, res) => {
    res.status(404).sendFile(__dirname + '/public/404.html');
});

// Start the server
app.listen(PORT, () => {
    console.log(`Server is running on http://localhost:${PORT}`);
});