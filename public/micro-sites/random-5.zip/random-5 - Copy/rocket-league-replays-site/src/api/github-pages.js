const BASE_URL = 'https://<your-github-username>.github.io/<your-repo-name>';

export const fetchStaticData = async (endpoint) => {
    try {
        const response = await fetch(`${BASE_URL}/${endpoint}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        return await response.json();
    } catch (error) {
        console.error('Error fetching static data:', error);
        throw error;
    }
};

export const redirectToReplay = (replayId) => {
    window.location.href = `${BASE_URL}/replays/${replayId}`;
};