const API_BASE_URL = 'https://ballchasing.com/api/replays';

export async function fetchReplays(page = 1, limit = 10) {
    try {
        const response = await fetch(`${API_BASE_URL}?page=${page}&limit=${limit}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching replays:', error);
        throw error;
    }
}

export async function fetchReplayDetails(replayId) {
    try {
        const response = await fetch(`${API_BASE_URL}/${replayId}`);
        if (!response.ok) {
            throw new Error('Network response was not ok');
        }
        const data = await response.json();
        return data;
    } catch (error) {
        console.error('Error fetching replay details:', error);
        throw error;
    }
}