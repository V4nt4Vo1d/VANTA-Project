// This file defines TypeScript types and interfaces used throughout the project.

export interface Replay {
    id: string;
    title: string;
    date: string;
    player: string;
    url: string;
}

export interface ApiResponse<T> {
    success: boolean;
    data: T;
    message?: string;
}

export interface State {
    replays: Replay[];
    loading: boolean;
    error?: string;
}

export type FetchReplaysResponse = ApiResponse<Replay[]>;

export type FetchReplayDetailsResponse = ApiResponse<Replay>;